
-- Restaurants (multi-unit ready for the future manager panel)
CREATE TABLE public.restaurants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text NOT NULL UNIQUE,
  address text,
  pix_key text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.restaurants TO anon, authenticated;
GRANT ALL ON public.restaurants TO service_role;
ALTER TABLE public.restaurants ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public can view active restaurants" ON public.restaurants
  FOR SELECT USING (is_active = true);

-- Menu categories
CREATE TABLE public.categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id uuid NOT NULL REFERENCES public.restaurants(id) ON DELETE CASCADE,
  slug text NOT NULL,
  name text NOT NULL,
  sort_order int NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (restaurant_id, slug)
);
GRANT SELECT ON public.categories TO anon, authenticated;
GRANT ALL ON public.categories TO service_role;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public can view active categories" ON public.categories
  FOR SELECT USING (is_active = true);
CREATE INDEX ix_categories_restaurant ON public.categories (restaurant_id, sort_order);

-- Food / menu items
CREATE TABLE public.food_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id uuid NOT NULL REFERENCES public.restaurants(id) ON DELETE CASCADE,
  category_id uuid NOT NULL REFERENCES public.categories(id) ON DELETE RESTRICT,
  slug text NOT NULL,
  name text NOT NULL,
  description text NOT NULL DEFAULT '',
  price numeric(10,2) NOT NULL CHECK (price >= 0),
  image_url text,
  is_active boolean NOT NULL DEFAULT true,
  is_featured boolean NOT NULL DEFAULT false,
  stock_quantity int,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (restaurant_id, slug)
);
GRANT SELECT ON public.food_items TO anon, authenticated;
GRANT ALL ON public.food_items TO service_role;
ALTER TABLE public.food_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public can view active items" ON public.food_items
  FOR SELECT USING (is_active = true);
CREATE INDEX ix_food_items_category ON public.food_items (category_id);

-- Orders
CREATE TYPE public.order_status AS ENUM ('received','preparing','ready','delivered','cancelled');
CREATE TYPE public.payment_mode AS ENUM ('pix','card','cash');
CREATE TYPE public.payment_status AS ENUM ('pending','paid','failed','refunded');

CREATE TABLE public.orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id uuid NOT NULL REFERENCES public.restaurants(id) ON DELETE RESTRICT,
  order_number text NOT NULL UNIQUE,
  table_label text,
  status public.order_status NOT NULL DEFAULT 'received',
  payment_mode public.payment_mode NOT NULL,
  subtotal numeric(10,2) NOT NULL CHECK (subtotal >= 0),
  total numeric(10,2) NOT NULL CHECK (total >= 0),
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.orders TO anon;
GRANT SELECT, INSERT, UPDATE ON public.orders TO authenticated;
GRANT ALL ON public.orders TO service_role;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Tablet can create orders" ON public.orders
  FOR INSERT WITH CHECK (true);
CREATE POLICY "Public can read orders by number" ON public.orders
  FOR SELECT USING (true);
CREATE INDEX ix_orders_restaurant_status ON public.orders (restaurant_id, status, created_at DESC);

-- Order items (line items)
CREATE TABLE public.order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  food_item_id uuid REFERENCES public.food_items(id) ON DELETE SET NULL,
  name_snapshot text NOT NULL,
  quantity int NOT NULL CHECK (quantity > 0),
  unit_price numeric(10,2) NOT NULL CHECK (unit_price >= 0),
  customizations jsonb NOT NULL DEFAULT '{}'::jsonb,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.order_items TO anon;
GRANT SELECT, INSERT, UPDATE ON public.order_items TO authenticated;
GRANT ALL ON public.order_items TO service_role;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Tablet can create order items" ON public.order_items
  FOR INSERT WITH CHECK (true);
CREATE POLICY "Public can read order items" ON public.order_items
  FOR SELECT USING (true);
CREATE INDEX ix_order_items_order ON public.order_items (order_id);

-- Payments (NO card data stored)
CREATE TABLE public.payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  mode public.payment_mode NOT NULL,
  status public.payment_status NOT NULL DEFAULT 'pending',
  amount numeric(10,2) NOT NULL CHECK (amount >= 0),
  provider text,
  provider_reference text,
  pix_payload text,
  paid_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.payments TO anon;
GRANT SELECT, INSERT, UPDATE ON public.payments TO authenticated;
GRANT ALL ON public.payments TO service_role;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Tablet can create payments" ON public.payments
  FOR INSERT WITH CHECK (true);
CREATE POLICY "Public can read payments" ON public.payments
  FOR SELECT USING (true);
CREATE INDEX ix_payments_order ON public.payments (order_id);

-- Seed: O Casarão restaurant + catalog mirroring the current UI
INSERT INTO public.restaurants (id, name, slug, address, pix_key)
VALUES ('11111111-1111-1111-1111-111111111111', 'O Casarão', 'casarao',
        'Rua das Acácias, 123 - São Paulo/SP', '+5511999999999');

INSERT INTO public.categories (restaurant_id, slug, name, sort_order) VALUES
  ('11111111-1111-1111-1111-111111111111','pratos','Pratos do Dia',1),
  ('11111111-1111-1111-1111-111111111111','espetinhos','Espetinhos',2),
  ('11111111-1111-1111-1111-111111111111','acompanhamentos','Acompanhamentos',3),
  ('11111111-1111-1111-1111-111111111111','bebidas','Bebidas',4),
  ('11111111-1111-1111-1111-111111111111','sobremesas','Sobremesas',5);

INSERT INTO public.food_items (restaurant_id, category_id, slug, name, description, price, is_featured)
SELECT '11111111-1111-1111-1111-111111111111', c.id, v.slug, v.name, v.description, v.price, v.featured
FROM public.categories c
JOIN (VALUES
  ('pratos','feijoada','Feijoada Completa','Arroz, farofa, couve mineira e laranja. Serve uma pessoa.',48.90,false),
  ('pratos','frango-quiabo','Frango com Quiabo','Acompanha polenta cremosa e arroz branco fresquinho.',42.00,false),
  ('espetinhos','esp-picanha','Espetinho de Picanha','Corte nobre na brasa com sal grosso.',18.00,true),
  ('espetinhos','esp-coracao','Espetinho de Coração','Coraçãozinho de frango temperado e grelhado.',14.00,false),
  ('bebidas','suco-laranja','Suco de Laranja','Natural, 400ml. Sem adição de açúcar.',12.00,false),
  ('sobremesas','pudim','Pudim de Leite','Receita da casa com calda de caramelo.',14.00,false)
) AS v(cat_slug, slug, name, description, price, featured)
  ON v.cat_slug = c.slug
WHERE c.restaurant_id = '11111111-1111-1111-1111-111111111111';
