import { Trash2, QrCode } from "lucide-react";
import { useCart } from "@/lib/cart-context";
import { formatBRL } from "@/lib/menu-data";

interface Props {
  onCheckout: () => void;
  onCallWaiter: () => void;
}

export function CartPanel({ onCheckout, onCallWaiter }: Props) {
  const { items, total, remove, count } = useCart();

  const describeSelections = (selections: Record<string, string[]>) => {
    const all = Object.values(selections).flat();
    if (!all.length) return null;
    return all.join(", ");
  };

  return (
    <aside className="w-96 bg-muted border-l border-border flex flex-col shrink-0">
      <div className="p-6 border-b border-border">
        <h2 className="font-display text-2xl uppercase tracking-wider text-clay">Seu Pedido</h2>
        <p className="text-xs text-muted-foreground mt-1 uppercase tracking-wider font-medium">
          Mesa 12 · {count} {count === 1 ? "item" : "itens"}
        </p>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {items.length === 0 ? (
          <div className="text-center py-16">
            <p className="text-sm text-muted-foreground italic">
              Seu pedido aparecerá aqui.
            </p>
          </div>
        ) : (
          items.map((line) => (
            <div key={line.lineId} className="flex justify-between items-start gap-3 group">
              <div className="flex gap-3 flex-1 min-w-0">
                <div className="size-7 bg-clay text-primary-foreground rounded text-xs flex items-center justify-center font-bold shrink-0">
                  {line.quantity}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="font-bold text-sm uppercase tracking-tight truncate">
                    {line.item.name}
                  </p>
                  {describeSelections(line.selections) && (
                    <p className="text-[11px] text-muted-foreground italic mt-0.5 line-clamp-2">
                      {describeSelections(line.selections)}
                    </p>
                  )}
                </div>
              </div>
              <div className="flex flex-col items-end gap-1">
                <span className="text-sm font-bold">
                  {formatBRL(line.unitPrice * line.quantity)}
                </span>
                <button
                  onClick={() => remove(line.lineId)}
                  className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive transition"
                  aria-label="Remover"
                >
                  <Trash2 className="size-3.5" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      <div className="p-6 bg-card border-t border-border">
        <div className="flex justify-between items-center mb-4">
          <span className="text-muted-foreground text-sm font-medium">Total</span>
          <span className="text-3xl font-display text-clay">{formatBRL(total)}</span>
        </div>

        <div className="bg-muted rounded-xl p-3 mb-4 flex items-center gap-3 border border-border">
          <div className="size-10 bg-card border border-border rounded flex items-center justify-center">
            <QrCode className="size-5 text-clay" />
          </div>
          <div>
            <p className="text-[10px] font-bold uppercase text-muted-foreground tracking-wider">
              Pague via Pix
            </p>
            <p className="text-[11px] text-muted-foreground leading-tight">
              QR Code é gerado ao confirmar
            </p>
          </div>
        </div>

        <button
          disabled={items.length === 0}
          onClick={onCheckout}
          className="w-full bg-clay text-primary-foreground py-4 rounded-xl font-bold uppercase tracking-widest shadow-[var(--shadow-warm)] active:scale-[0.98] transition-transform disabled:opacity-40 disabled:cursor-not-allowed"
        >
          Confirmar Pedido
        </button>

        <button
          onClick={onCallWaiter}
          className="w-full mt-3 text-clay text-xs font-bold uppercase tracking-widest hover:text-terracotta transition-colors"
        >
          Chamar garçom (pagar no cartão)
        </button>
      </div>
    </aside>
  );
}
