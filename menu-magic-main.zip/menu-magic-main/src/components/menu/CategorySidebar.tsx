import { UtensilsCrossed, Flame, Salad, GlassWater, Cake, BellRing } from "lucide-react";
import type { Category } from "@/lib/menu-data";
import { cn } from "@/lib/utils";

const ICONS: Record<Category, typeof UtensilsCrossed> = {
  pratos: UtensilsCrossed,
  espetinhos: Flame,
  acompanhamentos: Salad,
  bebidas: GlassWater,
  sobremesas: Cake,
};

const LABELS: Record<Category, string> = {
  pratos: "Pratos",
  espetinhos: "Espeto",
  acompanhamentos: "Sides",
  bebidas: "Drinks",
  sobremesas: "Doces",
};

interface Props {
  active: Category;
  onChange: (c: Category) => void;
  onCallWaiter: () => void;
}

export function CategorySidebar({ active, onChange, onCallWaiter }: Props) {
  const cats: Category[] = ["pratos", "espetinhos", "acompanhamentos", "bebidas", "sobremesas"];
  return (
    <aside className="w-24 flex flex-col items-center py-8 border-r border-border bg-card shrink-0">
      <div className="mb-10">
        <div className="size-12 bg-terracotta rounded-xl flex items-center justify-center text-primary-foreground font-display text-2xl">
          C
        </div>
      </div>
      <nav className="flex flex-col gap-6 flex-1">
        {cats.map((c) => {
          const Icon = ICONS[c];
          const isActive = c === active;
          return (
            <button
              key={c}
              onClick={() => onChange(c)}
              className={cn(
                "flex flex-col items-center gap-1 transition-colors",
                isActive ? "text-terracotta" : "text-muted-foreground hover:text-foreground"
              )}
            >
              <div
                className={cn(
                  "size-12 rounded-full flex items-center justify-center transition-colors",
                  isActive ? "bg-terracotta-soft" : "hover:bg-muted"
                )}
              >
                <Icon className="size-5" strokeWidth={2} />
              </div>
              <span className="text-[10px] font-bold uppercase tracking-wider">{LABELS[c]}</span>
            </button>
          );
        })}
      </nav>
      <button
        onClick={onCallWaiter}
        className="mt-auto flex flex-col items-center gap-1 text-muted-foreground hover:text-terracotta transition-colors"
      >
        <div className="size-12 rounded-full border border-border flex items-center justify-center">
          <BellRing className="size-5" />
        </div>
        <span className="text-[10px] font-bold uppercase tracking-wider">Garçom</span>
      </button>
    </aside>
  );
}
