import { Plus } from "lucide-react";
import type { MenuItem } from "@/lib/menu-data";
import { formatBRL } from "@/lib/menu-data";
import { cn } from "@/lib/utils";

interface Props {
  item: MenuItem;
  onSelect: (item: MenuItem) => void;
}

export function ProductCard({ item, onSelect }: Props) {
  const hasCustomization = !!item.customization?.length;
  return (
    <button
      onClick={() => onSelect(item)}
      className={cn(
        "text-left bg-card rounded-2xl p-4 shadow-[var(--shadow-soft)] flex gap-4 transition-all hover:shadow-[var(--shadow-warm)] hover:-translate-y-0.5",
        item.featured ? "border-2 border-terracotta" : "border border-border"
      )}
    >
      <img
        src={item.image}
        alt={item.name}
        loading="lazy"
        width={128}
        height={128}
        className="w-32 h-32 object-cover rounded-xl shrink-0"
      />
      <div className="flex flex-col justify-between flex-1 py-1 min-w-0">
        <div>
          <div className="flex items-start gap-2">
            <h3 className="font-bold text-lg leading-tight">{item.name}</h3>
          </div>
          {item.featured && (
            <span className="inline-block mt-1 text-[9px] bg-terracotta-soft text-terracotta px-2 py-0.5 rounded uppercase font-bold tracking-wide">
              Favorito
            </span>
          )}
          <p className="text-xs text-muted-foreground leading-relaxed mt-1 line-clamp-2">
            {item.description}
          </p>
        </div>
        <div className="flex items-center justify-between mt-2">
          <span className="font-bold text-clay text-lg">{formatBRL(item.price)}</span>
          {hasCustomization ? (
            <span className="px-3 py-1.5 rounded-lg bg-terracotta text-primary-foreground text-xs font-bold uppercase tracking-tight">
              Personalizar
            </span>
          ) : (
            <span className="size-9 rounded-lg bg-mustard flex items-center justify-center text-foreground">
              <Plus className="size-5" strokeWidth={2.5} />
            </span>
          )}
        </div>
      </div>
    </button>
  );
}
