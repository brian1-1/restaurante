import { useEffect, useState } from "react";
import { X, Check, Copy, CreditCard, Loader2 } from "lucide-react";
import { formatBRL } from "@/lib/menu-data";
import { useCart } from "@/lib/cart-context";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";

const RESTAURANT_ID = "11111111-1111-1111-1111-111111111111";

type Mode = "pix" | "card" | "done" | null;

interface Props {
  mode: Mode;
  onClose: () => void;
}

// Build a tiled "qr-like" SVG pattern as a placeholder.
// In production this would be a real Pix payload from the gateway.
function FakeQR({ seed }: { seed: string }) {
  const size = 21;
  const cells: boolean[] = [];
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) >>> 0;
  for (let i = 0; i < size * size; i++) {
    h = (h * 1103515245 + 12345) >>> 0;
    cells.push((h & 1) === 1);
  }
  const cellSize = 10;
  return (
    <svg
      viewBox={`0 0 ${size * cellSize} ${size * cellSize}`}
      className="size-56 rounded-lg bg-card"
      aria-label="Código Pix"
    >
      {cells.map((on, i) =>
        on ? (
          <rect
            key={i}
            x={(i % size) * cellSize}
            y={Math.floor(i / size) * cellSize}
            width={cellSize}
            height={cellSize}
            fill="currentColor"
          />
        ) : null
      )}
      {/* corner markers */}
      {[
        [0, 0],
        [(size - 7) * cellSize, 0],
        [0, (size - 7) * cellSize],
      ].map(([x, y]) => (
        <g key={`${x}-${y}`} fill="currentColor">
          <rect x={x} y={y} width={7 * cellSize} height={7 * cellSize} />
          <rect x={x + cellSize} y={y + cellSize} width={5 * cellSize} height={5 * cellSize} fill="white" />
          <rect x={x + 2 * cellSize} y={y + 2 * cellSize} width={3 * cellSize} height={3 * cellSize} />
        </g>
      ))}
    </svg>
  );
}

export function CheckoutModal({ mode, onClose }: Props) {
  const { total, clear, items } = useCart();
  const [confirmed, setConfirmed] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [orderNumber, setOrderNumber] = useState<string | null>(null);

  useEffect(() => {
    setConfirmed(false);
    setError(null);
    setOrderNumber(null);
  }, [mode]);

  if (!mode) return null;

  const handleSimulatePayment = async () => {
    if (submitting || mode === "done") return;
    setSubmitting(true);
    setError(null);
    try {
      const number = `OC-${Date.now().toString(36).toUpperCase()}`;
      const paymentMode = mode === "pix" ? "pix" : "card";

      const { data: order, error: orderErr } = await supabase
        .from("orders")
        .insert({
          restaurant_id: RESTAURANT_ID,
          order_number: number,
          table_label: "Mesa 12",
          status: "received",
          payment_mode: paymentMode,
          subtotal: total,
          total,
        })
        .select("id")
        .single();
      if (orderErr) throw orderErr;

      const rows = items.map((i) => ({
        order_id: order!.id,
        name_snapshot: i.item.name,
        quantity: i.quantity,
        unit_price: i.unitPrice,
        customizations: i.selections as unknown as import("@/integrations/supabase/types").Json,
        notes: i.notes ?? null,
      }));
      if (rows.length) {
        const { error: itemsErr } = await supabase.from("order_items").insert(rows);
        if (itemsErr) throw itemsErr;
      }

      const { error: payErr } = await supabase.from("payments").insert({
        order_id: order!.id,
        mode: paymentMode,
        status: paymentMode === "pix" ? "paid" : "pending",
        amount: total,
        provider: paymentMode === "pix" ? "pix-simulado" : "maquininha",
        pix_payload: paymentMode === "pix" ? pixKey : null,
        paid_at: paymentMode === "pix" ? new Date().toISOString() : null,
      });
      if (payErr) throw payErr;

      setOrderNumber(number);
      setConfirmed(true);
      setTimeout(() => {
        clear();
        onClose();
      }, 2600);
    } catch (e) {
      console.error(e);
      setError(e instanceof Error ? e.message : "Falha ao enviar pedido");
    } finally {
      setSubmitting(false);
    }
  };

  const pixKey = `00020126360014BR.GOV.BCB.PIX0114+5511999999999520400005303986540${total
    .toFixed(2)
    .padStart(6, "0")}5802BR5910RESTAURANTE6009SAO+PAULO`;

  return (
    <div
      className="fixed inset-0 bg-foreground/50 backdrop-blur-sm z-50 flex items-center justify-center p-6 animate-in fade-in"
      onClick={onClose}
    >
      <div
        className="bg-card rounded-3xl w-full max-w-md overflow-hidden shadow-[var(--shadow-warm)]"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between p-6 border-b border-border">
          <div>
            <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-bold">
              Pagamento · Mesa 12
            </p>
            <h3 className="font-display text-2xl text-clay mt-1">
              {mode === "pix" && "Pague via Pix"}
              {mode === "card" && "Garçom a caminho"}
              {mode === "done" && "Pedido confirmado!"}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="size-9 rounded-full bg-muted hover:bg-secondary flex items-center justify-center text-muted-foreground"
            aria-label="Fechar"
          >
            <X className="size-5" />
          </button>
        </div>

        <div className="p-6">
          {confirmed ? (
            <div className="py-10 text-center">
              <div className="size-20 mx-auto rounded-full bg-moss/10 flex items-center justify-center mb-4">
                <Check className="size-10 text-moss" strokeWidth={3} />
              </div>
              <h4 className="font-display text-3xl text-clay">Pedido enviado!</h4>
              {orderNumber && (
                <p className="mt-2 text-xs uppercase tracking-widest text-muted-foreground">
                  Nº <span className="font-mono text-clay">{orderNumber}</span>
                </p>
              )}
              <p className="text-muted-foreground text-sm mt-2 max-w-xs mx-auto">
                A cozinha já recebeu seu pedido. Bom apetite!
              </p>
            </div>
          ) : mode === "pix" ? (
            <>
              <div className="flex justify-center text-clay mb-4">
                <FakeQR seed={`${total}-${items.length}`} />
              </div>
              <p className="text-center text-sm text-muted-foreground mb-4">
                Aponte a câmera do seu banco para o código acima
              </p>
              <button
                className="w-full flex items-center justify-center gap-2 py-3 border border-border rounded-xl text-sm font-semibold text-muted-foreground hover:bg-muted transition"
                onClick={() => navigator.clipboard?.writeText(pixKey)}
              >
                <Copy className="size-4" /> Copiar Pix copia e cola
              </button>
              <div className="flex justify-between items-center mt-6 pt-6 border-t border-border">
                <span className="text-sm text-muted-foreground">Total</span>
                <span className="text-2xl font-display text-clay">{formatBRL(total)}</span>
              </div>
              <button
                onClick={handleSimulatePayment}
                disabled={submitting}
                className="w-full mt-4 bg-clay text-primary-foreground py-4 rounded-xl font-bold uppercase tracking-widest active:scale-[0.98] transition-transform flex items-center justify-center gap-2 disabled:opacity-60"
              >
                {submitting && <Loader2 className="size-4 animate-spin" />}
                {submitting ? "Enviando..." : "Já paguei"}
              </button>
              {error && (
                <p className="mt-3 text-xs text-center text-destructive">{error}</p>
              )}
            </>
          ) : (
            <div className="text-center py-6">
              <div className="size-20 mx-auto rounded-full bg-mustard/20 flex items-center justify-center mb-4">
                <CreditCard className="size-10 text-clay" strokeWidth={2} />
              </div>
              <p className="text-foreground text-base font-medium mb-2">
                Um garçom levará a maquininha até a sua mesa
              </p>
              <p className="text-muted-foreground text-sm">
                Tempo estimado: 2 minutos
              </p>
              <div className="flex justify-between items-center mt-6 pt-6 border-t border-border">
                <span className="text-sm text-muted-foreground">Total a pagar</span>
                <span className="text-2xl font-display text-clay">{formatBRL(total)}</span>
              </div>
              <button
                onClick={handleSimulatePayment}
                disabled={submitting}
                className={cn(
                  "w-full mt-4 bg-clay text-primary-foreground py-4 rounded-xl font-bold uppercase tracking-widest active:scale-[0.98] transition-transform flex items-center justify-center gap-2 disabled:opacity-60"
                )}
              >
                {submitting && <Loader2 className="size-4 animate-spin" />}
                {submitting ? "Enviando..." : "Confirmar pedido"}
              </button>
              {error && (
                <p className="mt-3 text-xs text-destructive">{error}</p>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
