import { useEffect, useMemo, useState } from "react";
import { X, Minus, Plus, Check } from "lucide-react";
import type { MenuItem } from "@/lib/menu-data";
import { formatBRL } from "@/lib/menu-data";
import { useCart } from "@/lib/cart-context";
import { cn } from "@/lib/utils";

interface Props {
  item: MenuItem | null;
  onClose: () => void;
}

export function CustomizationModal({ item, onClose }: Props) {
  const { add } = useCart();
  const [qty, setQty] = useState(1);
  const [selections, setSelections] = useState<Record<string, string[]>>({});

  useEffect(() => {
    if (!item) return;
    const init: Record<string, string[]> = {};
    item.customization?.forEach((g) => {
      if (g.type === "single" && g.required) init[g.id] = [g.options[0].id];
      else init[g.id] = [];
    });
    setSelections(init);
    setQty(1);
  }, [item]);

  const unitPrice = useMemo(() => {
    if (!item) return 0;
    let extra = 0;
    item.customization?.forEach((g) => {
      const sel = selections[g.id] ?? [];
      g.options.forEach((o) => {
        if (sel.includes(o.id) && o.priceDelta) extra += o.priceDelta;
      });
    });
    return item.price + extra;
  }, [item, selections]);

  if (!item) return null;

  const toggle = (groupId: string, optionId: string, type: "single" | "multi") => {
    setSelections((prev) => {
      const cur = prev[groupId] ?? [];
      if (type === "single") return { ...prev, [groupId]: [optionId] };
      return {
        ...prev,
        [groupId]: cur.includes(optionId) ? cur.filter((x) => x !== optionId) : [...cur, optionId],
      };
    });
  };

  const handleAdd = () => {
    add({ item, quantity: qty, selections, unitPrice });
    onClose();
  };

  return (
    <div
      className="fixed inset-0 bg-foreground/40 backdrop-blur-sm z-50 flex items-center justify-center p-6 animate-in fade-in"
      onClick={onClose}
    >
      <div
        className="bg-card rounded-3xl w-full max-w-3xl max-h-[90vh] overflow-hidden flex flex-col shadow-[var(--shadow-warm)]"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex">
          <img
            src={item.image}
            alt={item.name}
            width={320}
            height={320}
            className="w-72 h-auto object-cover hidden md:block"
          />
          <div className="flex-1 flex flex-col">
            <div className="p-8 pb-4 flex items-start justify-between">
              <div>
                <h3 className="font-display text-3xl text-clay">{item.name}</h3>
                <p className="text-muted-foreground text-sm mt-1">{item.description}</p>
                <p className="text-terracotta font-bold text-lg mt-2">{formatBRL(item.price)}</p>
              </div>
              <button
                onClick={onClose}
                className="size-9 rounded-full bg-muted hover:bg-secondary flex items-center justify-center text-muted-foreground"
                aria-label="Fechar"
              >
                <X className="size-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto px-8 space-y-6">
              {item.customization?.map((group) => (
                <section key={group.id}>
                  <h4 className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-3">
                    {group.label}
                    {group.required && <span className="text-terracotta ml-1">*</span>}
                  </h4>
                  <div className="space-y-2">
                    {group.options.map((opt) => {
                      const checked = (selections[group.id] ?? []).includes(opt.id);
                      return (
                        <button
                          key={opt.id}
                          onClick={() => toggle(group.id, opt.id, group.type)}
                          className={cn(
                            "w-full flex items-center justify-between p-4 rounded-xl border-2 transition-colors text-left",
                            checked
                              ? "border-terracotta bg-terracotta-soft"
                              : "border-border hover:border-muted-foreground/40"
                          )}
                        >
                          <div>
                            <span className="font-semibold">{opt.label}</span>
                            {opt.priceDelta ? (
                              <span className="ml-2 text-xs text-muted-foreground">
                                +{formatBRL(opt.priceDelta)}
                              </span>
                            ) : null}
                          </div>
                          {group.type === "single" ? (
                            <div
                              className={cn(
                                "size-5 rounded-full border-2",
                                checked ? "border-terracotta border-[6px]" : "border-border"
                              )}
                            />
                          ) : (
                            <div
                              className={cn(
                                "size-5 rounded border-2 flex items-center justify-center",
                                checked
                                  ? "border-terracotta bg-terracotta text-primary-foreground"
                                  : "border-border"
                              )}
                            >
                              {checked && <Check className="size-3" strokeWidth={3} />}
                            </div>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </section>
              ))}
            </div>

            <div className="p-6 border-t border-border bg-muted/30 flex items-center gap-4">
              <div className="flex items-center bg-card rounded-xl border border-border">
                <button
                  onClick={() => setQty((q) => Math.max(1, q - 1))}
                  className="size-11 flex items-center justify-center text-muted-foreground"
                  aria-label="Diminuir"
                >
                  <Minus className="size-4" />
                </button>
                <span className="px-3 font-bold w-8 text-center">{qty}</span>
                <button
                  onClick={() => setQty((q) => q + 1)}
                  className="size-11 flex items-center justify-center text-muted-foreground"
                  aria-label="Aumentar"
                >
                  <Plus className="size-4" />
                </button>
              </div>
              <button
                onClick={handleAdd}
                className="flex-1 py-4 bg-clay text-primary-foreground rounded-xl font-bold uppercase tracking-widest shadow-[var(--shadow-warm)] active:scale-[0.98] transition-transform"
              >
                Adicionar · {formatBRL(unitPrice * qty)}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
