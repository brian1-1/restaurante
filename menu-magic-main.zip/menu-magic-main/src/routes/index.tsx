import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";

import { CATEGORIES, MENU, type Category, type MenuItem } from "@/lib/menu-data";
import { CartProvider, useCart } from "@/lib/cart-context";
import { CategorySidebar } from "@/components/menu/CategorySidebar";
import { ProductCard } from "@/components/menu/ProductCard";
import { CartPanel } from "@/components/menu/CartPanel";
import { CustomizationModal } from "@/components/menu/CustomizationModal";
import { CheckoutModal } from "@/components/menu/CheckoutModal";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "O Casarão · Cardápio digital" },
      {
        name: "description",
        content:
          "Cardápio digital para tablet de mesa: pratos do dia, espetinhos, bebidas. Faça seu pedido e pague via Pix.",
      },
      { property: "og:title", content: "O Casarão · Cardápio digital" },
      {
        property: "og:description",
        content: "Cardápio digital para tablet de mesa do restaurante O Casarão.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <CartProvider>
      <MenuApp />
    </CartProvider>
  );
}

function MenuApp() {
  const [activeCategory, setActiveCategory] = useState<Category>("pratos");
  const [selectedItem, setSelectedItem] = useState<MenuItem | null>(null);
  const [checkoutMode, setCheckoutMode] = useState<"pix" | "card" | null>(null);
  const { add } = useCart();

  const items = useMemo(
    () => MENU.filter((m) => m.category === activeCategory),
    [activeCategory]
  );

  const categoryLabel = CATEGORIES.find((c) => c.id === activeCategory)?.label ?? "";

  const handleSelectItem = (item: MenuItem) => {
    if (item.customization?.length) {
      setSelectedItem(item);
    } else {
      add({ item, quantity: 1, selections: {}, unitPrice: item.price });
    }
  };

  return (
    <div className="flex h-screen w-full bg-paper text-foreground font-sans overflow-hidden">
      <CategorySidebar
        active={activeCategory}
        onChange={setActiveCategory}
        onCallWaiter={() => setCheckoutMode("card")}
      />

      <main className="flex-1 flex flex-col overflow-hidden">
        <header className="px-8 py-6 flex items-center justify-between border-b border-border bg-card">
          <div>
            <h1 className="font-display text-4xl text-clay tracking-wide">O Casarão</h1>
            <p className="text-xs text-muted-foreground uppercase tracking-[0.2em] font-medium mt-0.5">
              Cozinha Brasileira & Espetaria
            </p>
          </div>
          <div className="flex gap-2">
            {CATEGORIES.map((c) => (
              <button
                key={c.id}
                onClick={() => setActiveCategory(c.id)}
                className={
                  "px-5 py-2 rounded-full text-sm font-bold transition-colors " +
                  (activeCategory === c.id
                    ? "bg-clay text-primary-foreground"
                    : "bg-muted text-muted-foreground hover:bg-secondary")
                }
              >
                {c.label}
              </button>
            ))}
          </div>
        </header>

        <div className="flex-1 overflow-y-auto px-8 py-6">
          <h2 className="font-display text-3xl text-clay mb-5">{categoryLabel}</h2>
          {items.length === 0 ? (
            <div className="text-center py-20 text-muted-foreground">
              <p>Em breve nesta categoria.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {items.map((item) => (
                <ProductCard key={item.id} item={item} onSelect={handleSelectItem} />
              ))}
            </div>
          )}
        </div>
      </main>

      <CartPanel
        onCheckout={() => setCheckoutMode("pix")}
        onCallWaiter={() => setCheckoutMode("card")}
      />

      <CustomizationModal item={selectedItem} onClose={() => setSelectedItem(null)} />
      <CheckoutModal mode={checkoutMode} onClose={() => setCheckoutMode(null)} />

    </div>
  );
}
