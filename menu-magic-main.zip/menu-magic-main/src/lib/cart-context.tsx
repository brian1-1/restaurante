import { createContext, useContext, useMemo, useState, type ReactNode } from "react";
import type { MenuItem } from "./menu-data";

export interface CartItem {
  lineId: string;
  item: MenuItem;
  quantity: number;
  selections: Record<string, string[]>; // groupId -> optionIds
  unitPrice: number; // base + customization deltas
  notes?: string;
}

interface CartCtx {
  items: CartItem[];
  add: (item: Omit<CartItem, "lineId">) => void;
  updateQty: (lineId: string, qty: number) => void;
  remove: (lineId: string) => void;
  clear: () => void;
  total: number;
  count: number;
}

const Ctx = createContext<CartCtx | null>(null);

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);

  const value = useMemo<CartCtx>(() => {
    return {
      items,
      add: (i) =>
        setItems((prev) => [
          ...prev,
          { ...i, lineId: `${i.item.id}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}` },
        ]),
      updateQty: (lineId, qty) =>
        setItems((prev) =>
          qty <= 0
            ? prev.filter((p) => p.lineId !== lineId)
            : prev.map((p) => (p.lineId === lineId ? { ...p, quantity: qty } : p))
        ),
      remove: (lineId) => setItems((prev) => prev.filter((p) => p.lineId !== lineId)),
      clear: () => setItems([]),
      total: items.reduce((s, i) => s + i.unitPrice * i.quantity, 0),
      count: items.reduce((s, i) => s + i.quantity, 0),
    };
  }, [items]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useCart() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useCart must be used inside CartProvider");
  return c;
}
