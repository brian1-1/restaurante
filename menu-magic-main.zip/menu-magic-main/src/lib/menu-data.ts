import feijoada from "@/assets/feijoada.jpg";
import espetinhoPicanha from "@/assets/espetinho-picanha.jpg";
import espetinhoCoracao from "@/assets/espetinho-coracao.jpg";
import frangoQuiabo from "@/assets/frango-quiabo.jpg";
import sucoLaranja from "@/assets/suco-laranja.jpg";
import pudim from "@/assets/pudim.jpg";

export type Category = "pratos" | "espetinhos" | "acompanhamentos" | "bebidas" | "sobremesas";

export interface CustomizationOption {
  id: string;
  label: string;
  priceDelta?: number;
}
export interface CustomizationGroup {
  id: string;
  label: string;
  type: "single" | "multi";
  required?: boolean;
  options: CustomizationOption[];
}

export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: Category;
  featured?: boolean;
  customization?: CustomizationGroup[];
}

export const CATEGORIES: { id: Category; label: string }[] = [
  { id: "pratos", label: "Pratos do Dia" },
  { id: "espetinhos", label: "Espetinhos" },
  { id: "acompanhamentos", label: "Acompanhamentos" },
  { id: "bebidas", label: "Bebidas" },
  { id: "sobremesas", label: "Sobremesas" },
];

const pontoDaCarne: CustomizationGroup = {
  id: "ponto",
  label: "Ponto da Carne",
  type: "single",
  required: true,
  options: [
    { id: "mal", label: "Malpassado" },
    { id: "ao-ponto", label: "Ao Ponto" },
    { id: "bem", label: "Bem Passado" },
  ],
};

const acompanhamentoExtra: CustomizationGroup = {
  id: "acomp",
  label: "Acompanhamentos",
  type: "multi",
  options: [
    { id: "farofa", label: "Farofa da Casa", priceDelta: 0 },
    { id: "vinagrete", label: "Vinagrete", priceDelta: 2 },
    { id: "mandioca", label: "Mandioca Frita", priceDelta: 5 },
  ],
};

export const MENU: MenuItem[] = [
  {
    id: "feijoada",
    name: "Feijoada Completa",
    description: "Arroz, farofa, couve mineira e laranja. Serve uma pessoa.",
    price: 48.9,
    image: feijoada,
    category: "pratos",
  },
  {
    id: "frango-quiabo",
    name: "Frango com Quiabo",
    description: "Acompanha polenta cremosa e arroz branco fresquinho.",
    price: 42.0,
    image: frangoQuiabo,
    category: "pratos",
  },
  {
    id: "esp-picanha",
    name: "Espetinho de Picanha",
    description: "Corte nobre na brasa com sal grosso.",
    price: 18.0,
    image: espetinhoPicanha,
    category: "espetinhos",
    featured: true,
    customization: [pontoDaCarne, acompanhamentoExtra],
  },
  {
    id: "esp-coracao",
    name: "Espetinho de Coração",
    description: "Coraçãozinho de frango temperado e grelhado.",
    price: 14.0,
    image: espetinhoCoracao,
    category: "espetinhos",
    customization: [acompanhamentoExtra],
  },
  {
    id: "suco-laranja",
    name: "Suco de Laranja",
    description: "Natural, 400ml. Sem adição de açúcar.",
    price: 12.0,
    image: sucoLaranja,
    category: "bebidas",
  },
  {
    id: "pudim",
    name: "Pudim de Leite",
    description: "Receita da casa com calda de caramelo.",
    price: 14.0,
    image: pudim,
    category: "sobremesas",
  },
];

export const formatBRL = (v: number) =>
  v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
